package com.example.a13;

public class Movie {
String Helo;
String mainActor;
Double movieRate ;
int pgRate ;
String genre;

}
